<?php

namespace App\Domains\Marketplace\Repositories\Contracts;

interface PortalRepositoryInterface
{
    public function domainKey();
}
